 function mostrarTab(id, event) {
      // Oculta todos los contenidos
      document.querySelectorAll('.contenido').forEach(c => c.classList.remove('activo'));
      // Quita la clase activa de todos los botones
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('activa'));
      // Muestra el contenido correspondiente
      document.getElementById(id).classList.add('activo');
      // Marca el botón como activo
      event.currentTarget.classList.add('activa');
    }