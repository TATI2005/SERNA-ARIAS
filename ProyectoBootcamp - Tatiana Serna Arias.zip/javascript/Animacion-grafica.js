
/*Obtenemos el lienzo canvas donde dibujaremos el gráfico*/
const canvas = document.getElementById("grafico"); 
const ctx = canvas.getContext("2d"); /*Configuramos el contexto en modo 2D para dibujar*/

/*Alturas base de las barras los valores iniciales*/
let barras = [60, 120, 90, 150, 110]; 

/*Variable que controla el paso del tiempo sirve para el movimiento*/
let tiempo = 0;

/*Función principal que dibuja y anima las barras*/
function animar() {
  /*Limpia el lienzo antes de volver a dibujar para evitar que se acumulen las figuras*/
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  /*Colores distintos para cada barra*/
  const colores = ["#4A90E2", "#50E3C2", "#9B5DE0", "#2F5755", "#B8E986"];

  /*Recorre todas las barras*/
  for (let i = 0; i < barras.length; i++) {
    ctx.fillStyle = colores[i]; /*Asigna un color a cada barra*/

    /*Cálculo de altura con movimiento suave, sube y baja*/
    /*Math.sin() genera un valor entre -1 y 1 → hace que las barras oscilen*/
    /*tiempo / 20 controla la velocidad del movimiento*/
    let altura = barras[i] + Math.sin(tiempo / 20 + i) * 15;

    /*Dibuja la barra*/
    /*Parámetros: posiciónX, posiciónY, ancho, alto*/
    /*La posición Y se calcula desde abajo hacia arriba (por eso usamos canvas.height - altura)*/
    ctx.fillRect(50 + i * 60, canvas.height - altura, 40, altura);
  }

  /*Aumentamos el tiempo para que la animación continúe*/
  tiempo++;

  /*Llamamos nuevamente a la función animar y crea el bucle de animación*/
  requestAnimationFrame(animar);
}

/*Llamamos a la función para iniciar la animación*/
animar();
