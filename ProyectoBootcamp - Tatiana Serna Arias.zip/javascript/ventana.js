
function abrirVentana(id) {
  document.getElementById(id).style.display = "flex";
}

function cerrarVentana(id) {
  document.getElementById(id).style.display = "none";
}
