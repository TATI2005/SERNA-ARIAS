/*Documentacion de JavaScript*/

const menuBtn = document.getElementById("menuBtn"); /*Selecciona el boton del menu*/
const navLinks = document.getElementById("navLinks") /*Selecciona los enlaces de navegacion*/
const links = navLinks.querySelectorAll("a")

/*Agrega un evento de escucha al boton del menu*/
menuBtn.addEventListener("click", () => { /*un método que escucha está atento a un evento específico*/
    navLinks.classList.toggle("active");
     /*Agrega o quita la clase nav-active a los enlaces de navegacion*/
    if (navLinks.classList.contains("active")) {
        menuBtn.innerHTML = "<i class='fa-solid fa-xmark'></i>"; /*Cambia el icono del boton del menu a una X*/
        menuBtn.setAttribute("aria-expanded", "true"); /*Cambia el atributo aria-expanded a true*/  
    } else {
        menuBtn.innerHTML = "<i class='fa-solid fa-bars'></i>"; /*Cambia el icono del boton del menu a las tres barras*/
        menuBtn.setAttribute("aria-expanded", "false"); /*Cambia el atributo aria-expanded a false*/
    }
});

links.forEach(link => { /*un método para recorrer cada elemento de una lista*/
    link.addEventListener("click", () =>{
        navLinks.classList.remove("active");
        menuBtn.innerHTML = "<i class='fa-solid fa-bars'></i>";
        menuBtn.setAttribute("aria-expanded", "false");
    })
});